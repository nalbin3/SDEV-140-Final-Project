
'''
Author:  Nicholas Albin
Date written: 2/28/2025
Assignment:   Final Project
Short Desc:   fitness logging application
'''

import tkinter as tk
from tkinter import messagebox
from datetime import datetime

class FitnessApp:
    # Constructor to initialize the FitnessApp class
    def __init__(self, root):
        self.root = root
        self.root.title("The Fitness Journal")
        
        self.workouts = []  # List to store workout logs
        self.goals = []  # List to store fitness goals
        
        # Main Window
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack()
        
        tk.Label(self.main_frame, text="The Fitness Journal", font=("Helvetica", 16)).pack(pady=10)
        
        tk.Button(self.main_frame, text="Log Workout", command=self.show_log_workout).pack(pady=5)
        tk.Button(self.main_frame, text="Workout History", command=self.show_workout_history).pack(pady=5)
        tk.Button(self.main_frame, text="Manage Goals", command=self.show_manage_goals).pack(pady=5)
        tk.Button(self.main_frame, text="View Goals", command=self.view_goals).pack(pady=5)
        tk.Button(self.main_frame, text="Exit", command=root.quit).pack(pady=20)
    
    # Method to display the log workout window
    def show_log_workout(self):
        log_window = tk.Toplevel(self.root)
        log_window.title("Log Workout")
        
        tk.Label(log_window, text="Workout Name").pack(pady=5)
        workout_name = tk.Entry(log_window)  # Input for workout name
        workout_name.pack(pady=5)
        
        tk.Label(log_window, text="Sets").pack(pady=5)
        workout_sets = tk.Entry(log_window)  # Input for number of sets
        workout_sets.pack(pady=5)
        
        tk.Label(log_window, text="Reps").pack(pady=5)
        workout_reps = tk.Entry(log_window)  # Input for number of reps
        workout_reps.pack(pady=5)
        
        tk.Label(log_window, text="Comments").pack(pady=5)
        workout_comments = tk.Entry(log_window)  # Input for comments
        workout_comments.pack(pady=5)
        
        tk.Label(log_window, text="Date (MM-DD-YYYY)").pack(pady=5)
        workout_date = tk.Entry(log_window)  # Input for workout date
        workout_date.pack(pady=5)
        
        tk.Label(log_window, text="Did you workout?").pack(pady=5)
        workout_status = tk.StringVar()  # Variable to store workout status
        workout_status.set("Yes")
        tk.Radiobutton(log_window, text="Yes", variable=workout_status, value="Yes").pack(pady=5)
        tk.Radiobutton(log_window, text="No", variable=workout_status, value="No").pack(pady=5)
        
        # Method to add a workout to the workouts list
        def add_workout():
            name = workout_name.get()
            sets = workout_sets.get()
            reps = workout_reps.get()
            comments = workout_comments.get()
            date = workout_date.get()
            status = workout_status.get()
            try:
                datetime.strptime(date, "%m-%d-%Y")  # Validate date format
                if status == "Yes":
                    if name and sets.isdigit() and reps.isdigit():  # Check if inputs are valid
                        self.workouts.append((name, sets, reps, comments, date))
                        messagebox.showinfo("Success", "Workout logged successfully")
                        log_window.destroy()
                    else:
                        messagebox.showerror("Error", "Invalid input")
                else:
                    self.workouts.append(("No Workout", "0", "0", comments, date))
                    messagebox.showinfo("Success", "Rest day logged successfully")
                    log_window.destroy()
            except ValueError:
                messagebox.showerror("Error", "Invalid date format")
        
        tk.Button(log_window, text="Add Workout", command=add_workout).pack(pady=10)
        tk.Button(log_window, text="Exit", command=log_window.destroy).pack(pady=10)
    
    # Method to display the workout history window
    def show_workout_history(self):
        history_window = tk.Toplevel(self.root)
        history_window.title("Workout History")
        
        tk.Label(history_window, text="Workout History", font=("Helvetica", 14)).pack(pady=10)
        
        for i, workout in enumerate(self.workouts):
            workout_frame = tk.Frame(history_window)
            workout_frame.pack(fill='x', pady=5)
            tk.Label(workout_frame, text=f"Name: {workout[0]}, Sets: {workout[1]}, Reps: {workout[2]}, Comments: {workout[3]}, Date: {workout[4]}").pack(side='left', padx=10)
            tk.Button(workout_frame, text="Delete", command=lambda i=i: self.delete_workout(i)).pack(side='right', padx=10)
        
        tk.Button(history_window, text="Exit", command=history_window.destroy).pack(pady=10)
    
    # Method to delete a workout from the workouts list
    def delete_workout(self, index):
        del self.workouts[index]
        messagebox.showinfo("Success", "Workout deleted successfully")
    
    # Method to display the manage goals window
    def show_manage_goals(self):
        goals_window = tk.Toplevel(self.root)
        goals_window.title("Manage Goals")
        
        tk.Label(goals_window, text="Fitness Goals", font=("Helvetica", 14)).pack(pady=10)
        
        goal_name = tk.Entry(goals_window)  # Input for goal name
        goal_name.pack(pady=5)
        
        # Method to add a goal to the goals list
        def add_goal():
            goal = goal_name.get()
            if goal:
                self.goals.append(goal)
                self.update_goals_list(goals_window)
                messagebox.showinfo("Success", "Goal added successfully")
                goal_name.delete(0, tk.END)
            else:
                messagebox.showerror("Error", "Goal cannot be empty")
        
        tk.Button(goals_window, text="Add Goal", command=add_goal).pack(pady=5)
        tk.Button(goals_window, text="Exit", command=goals_window.destroy).pack(pady=10)
        
        self.goals_list = tk.Frame(goals_window)
        self.goals_list.pack(pady=5)
    
    # Method to update the goals list display
    def update_goals_list(self, parent_window):
        for widget in self.goals_list.winfo_children():
            widget.destroy()
        
        for goal in self.goals:
            goal_frame = tk.Frame(self.goals_list)
            goal_frame.pack(fill='x', pady=5)
            tk.Label(goal_frame, text=goal).pack(side='left', padx=10)
            tk.Button(goal_frame, text="Delete", command=lambda g=goal: self.delete_goal(g)).pack(side='right', padx=10)
    
    # Method to delete a goal from the goals list
    def delete_goal(self, goal):
        if goal in self.goals:
            self.goals.remove(goal)
            self.update_goals_list(self.goals_list.master)
            messagebox.showinfo("Success", "Goal deleted successfully")
    
    # Method to display the view goals window
    def view_goals(self):
        view_window = tk.Toplevel(self.root)
        view_window.title("View Goals")
        
        tk.Label(view_window, text="Your Fitness Goals", font=("Helvetica", 14)).pack(pady=10)
        
        for goal in self.goals:
            goal_frame = tk.Frame(view_window)
            goal_frame.pack(fill='x', pady=5)
            tk.Label(goal_frame, text=goal).pack(side='left', padx=10)
            tk.Button(goal_frame, text="Delete", command=lambda g=goal: self.delete_goal(g)).pack(side='right', padx=10)
        
        tk.Button(view_window, text="Exit", command=view_window.destroy).pack(pady=10)

if __name__ == "__main__":
    root = tk.Tk()
    app = FitnessApp(root)
    root.mainloop()



















    






    
        
